# Ikeja practice dataset (Data Decoded)

SIMULATED data for teaching. It does not describe any real company, customer or branch.
Built for the chapter "The Number Everyone Celebrated" in *Data Decoded* by Peter Fatolu.

Period: 1 September 2026 to 31 October 2026. One branch (Ikeja, Lagos). Currency: naira.

## Files
| File | Rows | What it holds |
|---|---|---|
| ikeja_sales_lines.csv | 2,690 | One row per product line sold |
| ikeja_products.csv | 45 | Product list, category, list price and unit cost |
| ikeja_returns.csv | 60 | One row per returned line (1 unit each) |
| ikeja.db | 4 tables | SQLite copy of the three files plus a one-row `branches` table, for the SQL examples |
| check_ikeja.py | - | Re-runs the chapter's key figures so you can confirm your copy is intact |

## Columns
**ikeja_sales_lines.csv**: line_id, sale_date (YYYY-MM-DD), product_id, qty, discount_pct (0.10 = 10%), branch_id
**ikeja_products.csv**: product_id, product_name, category, list_price, unit_cost
**ikeja_returns.csv**: line_id, qty_returned, reason
**branches (ikeja.db only)**: branch_id, branch_name

## Definitions used in the chapter
list_value = qty x list_price
invoiced = list_value x (1 - discount_pct)
discount_given = list_value - invoiced
refunded = qty_returned x list_price x (1 - discount_pct)
cogs = qty x unit_cost
gross profit = invoiced - refunded - cogs
Join returns to sales on line_id with a LEFT JOIN (most lines have no return).

## Quick start
Excel: open the CSV files, then XLOOKUP product_id into the products sheet.
Python: pd.read_csv("ikeja_sales_lines.csv", parse_dates=["sale_date"])
SQL: sqlite3 ikeja.db   (tables: sales_lines, products, returns, branches)

Licence: free to use for learning and teaching. Please credit "Data Decoded, Peter Fatolu".
