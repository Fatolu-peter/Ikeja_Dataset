"""Run: python check_ikeja.py   (needs pandas). Prints PASS/FAIL against the chapter's figures."""
import pandas as pd
s = pd.read_csv("ikeja_sales_lines.csv", parse_dates=["sale_date"])
p = pd.read_csv("ikeja_products.csv"); r = pd.read_csv("ikeja_returns.csv")
df = s.merge(p, on="product_id").merge(r, on="line_id", how="left")
df["qty_returned"] = df["qty_returned"].fillna(0)
df["month"] = df.sale_date.dt.strftime("%Y-%m")
df["list_value"] = df.qty * df.list_price
df["invoiced"] = df.list_value * (1 - df.discount_pct)
df["refunded"] = df.qty_returned * df.list_price * (1 - df.discount_pct)
df["gp"] = df.invoiced - df.refunded - df.qty * df.unit_cost
m = df.groupby("month")[["invoiced", "refunded", "gp"]].sum().round(0)
checks = {
 "2,690 sales lines": len(s) == 2690,
 "60 returns, 60 units": len(r) == 60 and r.qty_returned.sum() == 60,
 "Sept invoiced 15,450,020": m.loc["2026-09", "invoiced"] == 15450020,
 "Oct invoiced 20,255,740": m.loc["2026-10", "invoiced"] == 20255740,
 "Sept refunds 122,825": m.loc["2026-09", "refunded"] == 122825,
 "Oct refunds 720,950": m.loc["2026-10", "refunded"] == 720950,
 "Sept gross profit 3,454,995": m.loc["2026-09", "gp"] == 3454995,
 "Oct gross profit 2,709,790": m.loc["2026-10", "gp"] == 2709790,
}
for k, v in checks.items(): print("PASS" if v else "FAIL", k)
